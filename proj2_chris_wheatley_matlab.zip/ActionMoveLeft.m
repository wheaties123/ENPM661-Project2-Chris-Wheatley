% This function finds the new x,y coordinate after moving left by 1

function [x,y] = ActionMoveLeft(xx,yy)

    y=yy;
    x=xx-1;

end