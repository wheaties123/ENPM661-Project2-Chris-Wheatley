% This function finds the new x,y coordinate after moving down by 1 and
%   right by 1

function [x,y] = ActionMoveDownRight(xx,yy)

    y=yy-1;
    x=xx+1;

end