% This function finds the new x,y coordinate after moving up by 1 and
%   left by 1

function [x,y] = ActionMoveUpLeft(xx,yy)

    y=yy+1;
    x=xx-1;

end