% This function finds the new x,y coordinate after moving up by 1

function [x,y] = ActionMoveUp(xx,yy)

    y=yy+1;
    x=xx;

end