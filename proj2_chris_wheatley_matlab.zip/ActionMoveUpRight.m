% This function finds the new x,y coordinate after moving up by 1 and
%   right by 1

function [x,y] = ActionMoveUpRight(xx,yy)

    y=yy+1;
    x=xx+1;

end
