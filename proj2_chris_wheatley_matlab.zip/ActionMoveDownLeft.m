% This function finds the new x,y coordinate after moving down by 1 and
%   left by 1

function [x,y] = ActionMoveDownLeft(xx,yy)

    y=yy-1;
    x=xx-1;

end
