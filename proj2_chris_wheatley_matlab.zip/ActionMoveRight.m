% This function finds the new x,y coordinate after moving right by 1

function [x,y] = ActionMoveRight(xx,yy)

    y=yy;
    x=xx+1;

end